from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os
from launch.substitutions import Command
from launch_ros.parameter_descriptions import ParameterValue

def generate_launch_description():
    # Recupera percorso del pacchetto puma560_moveit1 (dove stanno urdf/srdf/config)
    puma_pkg = get_package_share_directory('puma560_moveit1')

    # File Xacro (non URDF!)
    xacro_file = os.path.join(puma_pkg, 'urdf', 'puma560_wrapper.urdf.xacro')
    srdf_file = os.path.join(puma_pkg, 'srdf', 'puma560_wrapper.srdf')
    moveit_config_file = os.path.join(puma_pkg, 'config', 'move_group.yaml')

    # Genera il robot_description usando xacro al volo
    robot_description = ParameterValue(
        Command(['xacro', xacro_file]),
        value_type=str
    )

    # Carica SRDF staticamente
    with open(srdf_file, 'r') as f:
        robot_description_semantic = f.read()

    # Nodo robot_state_publisher con parametro robot_description
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_description
        }]
    )

    # Nodo move_group
    move_group = Node(
        package='moveit_ros_move_group',
        executable='move_group',
        output='screen',
        parameters=[
            {'robot_description': robot_description},
            {'robot_description_semantic': robot_description_semantic},
            moveit_config_file
        ]
    )

    # Carica e attiva i controller
    load_joint_state_broadcaster = ExecuteProcess(
        cmd=['ros2', 'control', 'load_controller', '--set-state', 'active', 'joint_state_broadcaster'],
        output='screen'
    )

    load_arm_controller = ExecuteProcess(
        cmd=['ros2', 'control', 'load_controller', '--set-state', 'active', 'puma_arm_controller'],
        output='screen'
    )

    # Nodo pick and place
    pick_place_node = Node(
        package='hello_moveit',
        executable='hello_moveit_pick_place',
        name='hello_moveit_pick_place',
        output='screen'
    )

    return LaunchDescription([
        robot_state_publisher,
        move_group,
        load_joint_state_broadcaster,
        load_arm_controller,
        pick_place_node
    ])
