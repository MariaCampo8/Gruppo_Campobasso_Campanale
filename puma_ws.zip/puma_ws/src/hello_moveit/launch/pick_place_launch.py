from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    # Include demo.launch.py
    puma_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('puma560_moveit1'),
                'launch',
                'demo.launch.py'
            )
        )
    )

    # Nodo pick and place
    pick_place_node = Node(
        package='hello_moveit',
        executable='hello_moveit_pick_place',
        name='hello_moveit_pick_place',
        output='screen'
    )

    # Avvia pick_place_node con un ritardo (es. 5 secondi)
    delayed_pick_place = TimerAction(
        period=5.0,
        actions=[pick_place_node]
    )

    return LaunchDescription([
        puma_launch,
        delayed_pick_place
    ])
