#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit_msgs/msg/display_trajectory.hpp>
#include <geometric_shapes/shape_operations.h>
#include <shape_msgs/msg/solid_primitive.hpp>
#include <geometry_msgs/msg/pose.hpp>

int main(int argc, char * argv[])
{
  // inizializzo ros 
  rclcpp::init(argc, argv);
  auto node = rclcpp::Node::make_shared("hello_moveit");

  // avvia ros2 e crea un nodo 
  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(node);
  std::thread([&executor]() { executor.spin(); }).detach();

  // crea interfaccia puma_arm
  moveit::planning_interface::MoveGroupInterface move_group(node, "puma_arm");
  moveit::planning_interface::PlanningSceneInterface planning_scene_interface;

  // attesa per due secondi 
  rclcpp::sleep_for(std::chrono::seconds(2));

  // oggetto di collisione definito
  moveit_msgs::msg::CollisionObject collision_object;
  collision_object.header.frame_id = move_group.getPlanningFrame();
  collision_object.id = "box1";

  shape_msgs::msg::SolidPrimitive primitive;
  primitive.type = primitive.BOX;
  primitive.dimensions = {0.4, 0.1, 0.3};  // altezza,profondità,larghezza

  // posa del box
  geometry_msgs::msg::Pose box_pose;
  box_pose.orientation.w = 1.0;
  box_pose.position.x = 0.5;
  box_pose.position.y = 0.0;
  box_pose.position.z = 0.15;

  collision_object.primitives.push_back(primitive);
  collision_object.primitive_poses.push_back(box_pose);
  collision_object.operation = collision_object.ADD;

  // oggetto di collisione nella scena 
  planning_scene_interface.applyCollisionObjects({collision_object});
  RCLCPP_INFO(node->get_logger(), "Added collision object into the world");

  // attesa per due secondi 
  rclcpp::sleep_for(std::chrono::seconds(2));

  // imposto una posizione target goal_position
  // move_group.setNamedTarget("goal_position");
  geometry_msgs::msg::Pose target_pose;
  target_pose.orientation.w = 1.0;
  target_pose.position.x = 0.4;
  target_pose.position.y = -0.2;
  target_pose.position.z = 0.5;

  move_group.setPoseTarget(target_pose);


  // plan ed esecuzione
  moveit::planning_interface::MoveGroupInterface::Plan plan;
  bool success = (move_group.plan(plan) == moveit::core::MoveItErrorCode::SUCCESS);

  if (success)
  {
    RCLCPP_INFO(node->get_logger(), "Planning succeeded");
    
  }
  else
  {
    RCLCPP_ERROR(node->get_logger(), "Planning failed!");
  }

  
  rclcpp::shutdown();
  return 0;
}