#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit_msgs/msg/display_trajectory.hpp>

int main(int argc, char * argv[])
{
  // inizializza ros
  rclcpp::init(argc, argv);
  auto node = rclcpp::Node::make_shared("hello_moveit");

  // lancio il nodo in un thread separato per ricevere e pubblicare i messaggi 
  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(node);
  std::thread([&executor]() { executor.spin(); }).detach();

  // creo interfaccia per l'arm robotico 
  moveit::planning_interface::MoveGroupInterface move_group(node, "puma_arm");

  // 1 secondo di attesa 
  rclcpp::sleep_for(std::chrono::seconds(1));

  // uso posizione predefinita del robot 
  move_group.setNamedTarget("goal_position");

  // plan e esecuzione
  moveit::planning_interface::MoveGroupInterface::Plan plan;
bool success = (move_group.plan(plan) == moveit::core::MoveItErrorCode::SUCCESS);

if (success)
{
  RCLCPP_INFO(node->get_logger(), "Planning succeeded");
  
}
else
{
  RCLCPP_ERROR(node->get_logger(), "Planning failed!");
}


  
  rclcpp::shutdown();
  return 0;
}
