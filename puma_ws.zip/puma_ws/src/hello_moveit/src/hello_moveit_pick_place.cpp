#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit_msgs/msg/collision_object.hpp>
#include <moveit_msgs/msg/attached_collision_object.hpp>
#include <shape_msgs/msg/solid_primitive.hpp>
#include <geometry_msgs/msg/pose.hpp>
#include <thread>

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  auto node = rclcpp::Node::make_shared("hello_moveit_pick_place");

  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(node);
  std::thread spinner([&executor]() { executor.spin(); });

  moveit::planning_interface::MoveGroupInterface move_group(node, "puma_arm");
  moveit::planning_interface::PlanningSceneInterface planning_scene_interface;

  const std::string end_effector_link = "link6";
  const std::string planning_frame = move_group.getPlanningFrame();

  RCLCPP_INFO(node->get_logger(), "Planning frame: %s", planning_frame.c_str());

  rclcpp::sleep_for(std::chrono::seconds(2));

  // === 1. Aggiungi la sfera ===
  moveit_msgs::msg::CollisionObject sphere;
  sphere.header.frame_id = planning_frame;
  sphere.id = "pick_sphere";

  shape_msgs::msg::SolidPrimitive sphere_primitive;
  sphere_primitive.type = shape_msgs::msg::SolidPrimitive::SPHERE;
  sphere_primitive.dimensions = {0.05};  // raggio

  geometry_msgs::msg::Pose sphere_pose;
  sphere_pose.orientation.w = 1.0;
  sphere_pose.position.x = 0.4;
  sphere_pose.position.y = 0.0;
  sphere_pose.position.z = 0.1;

  sphere.primitives.push_back(sphere_primitive);
  sphere.primitive_poses.push_back(sphere_pose);
  sphere.operation = moveit_msgs::msg::CollisionObject::ADD;

  // === 2. Costruisci lo scaffale ===
  std::vector<moveit_msgs::msg::CollisionObject> shelf_parts;

  auto create_box = [&](const std::string& id,
                        const std::array<double, 3>& size,
                        const std::array<double, 3>& pos) {
    moveit_msgs::msg::CollisionObject box;
    box.header.frame_id = planning_frame;
    box.id = id;

    shape_msgs::msg::SolidPrimitive prim;
    prim.type = shape_msgs::msg::SolidPrimitive::BOX;
    prim.dimensions.assign(size.begin(), size.end());

    geometry_msgs::msg::Pose pose;
    pose.orientation.w = 1.0;
    pose.position.x = pos[0];
    pose.position.y = pos[1];
    pose.position.z = pos[2];

    box.primitives.push_back(prim);
    box.primitive_poses.push_back(pose);
    box.operation = moveit_msgs::msg::CollisionObject::ADD;
    return box;
  };

  const std::array<double, 3> shelf_base_size = {1.0, 0.3, 0.02};
  const std::array<double, 3> shelf_base_pos = {0.0, 0.45, 0.3};

  const std::array<double, 3> shelf_leg_size = {0.02, 0.02, 0.5};

  shelf_parts.push_back(create_box("shelf_base", shelf_base_size, shelf_base_pos));
  shelf_parts.push_back(create_box("shelf_leg_left_forward", shelf_leg_size, {-0.5, 0.3, 0.25}));
  shelf_parts.push_back(create_box("shelf_leg_left_behind", shelf_leg_size, {-0.5, 0.6, 0.25}));
  shelf_parts.push_back(create_box("shelf_leg_right_forward", shelf_leg_size, {0.5, 0.3, 0.25}));
  shelf_parts.push_back(create_box("shelf_leg_right_behind", shelf_leg_size, {0.5, 0.6, 0.25}));

  // === 3. Inserisci gli oggetti nella scena ===
  planning_scene_interface.applyCollisionObjects({sphere});
  planning_scene_interface.applyCollisionObjects(shelf_parts);
  rclcpp::sleep_for(std::chrono::seconds(2));

  // === 4. Muoviti sopra la sfera ===
  geometry_msgs::msg::Pose pre_grasp_pose = sphere_pose;
  pre_grasp_pose.position.z += 0.1;
  move_group.setPoseTarget(pre_grasp_pose);
  move_group.move();

  // === 5. Scendi sulla sfera ===
  move_group.setPoseTarget(sphere_pose);
  move_group.move();

  // === 6. Attacca la sfera ===
  moveit_msgs::msg::AttachedCollisionObject attached_obj;
  attached_obj.link_name = end_effector_link;
  attached_obj.object = sphere;
  attached_obj.touch_links = std::vector<std::string>{end_effector_link};
  planning_scene_interface.applyAttachedCollisionObject(attached_obj);
  RCLCPP_INFO(node->get_logger(), "Attached the sphere.");
  rclcpp::sleep_for(std::chrono::seconds(2));

  // === 7. Solleva la sfera ===
  pre_grasp_pose.position.z += 0.05;
  move_group.setPoseTarget(pre_grasp_pose);
  move_group.move();

  // === 8. Vai sopra lo scaffale ===
  geometry_msgs::msg::Pose shelf_pose;
  shelf_pose.orientation.w = 1.0;
  shelf_pose.position.x = 0.6;
  shelf_pose.position.y = 0.0;
  shelf_pose.position.z = 0.12;
  move_group.setPoseTarget(shelf_pose);
  move_group.move();

  // === 9. Rilascia la sfera ===
  moveit_msgs::msg::AttachedCollisionObject detach_obj;
  detach_obj.link_name = end_effector_link;
  detach_obj.object.id = sphere.id;
  detach_obj.object.operation = moveit_msgs::msg::CollisionObject::REMOVE;
  planning_scene_interface.applyAttachedCollisionObject(detach_obj);
  rclcpp::sleep_for(std::chrono::seconds(1));

  // === 10. Reinserisci la sfera sulla mensola ===
  sphere_pose = shelf_pose;
  sphere_pose.position.z += 0.05;
  sphere.primitive_poses.clear();
  sphere.primitive_poses.push_back(sphere_pose);
  sphere.operation = moveit_msgs::msg::CollisionObject::ADD;
  planning_scene_interface.applyCollisionObjects({sphere});

  RCLCPP_INFO(node->get_logger(), "Pick and place completato.");

  rclcpp::shutdown();
  spinner.join();
  return 0;
}