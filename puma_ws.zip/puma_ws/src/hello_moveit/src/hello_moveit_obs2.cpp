#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit_msgs/msg/display_trajectory.hpp>
#include <geometric_shapes/shape_operations.h>
#include <shape_msgs/msg/solid_primitive.hpp>
#include <geometry_msgs/msg/pose.hpp>

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  auto node = rclcpp::Node::make_shared("hello_moveit");

  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(node);
  std::thread([&executor]() { executor.spin(); }).detach();

  // MoveIt interfaces
  moveit::planning_interface::MoveGroupInterface move_group(node, "puma_arm");
  moveit::planning_interface::PlanningSceneInterface planning_scene_interface;

  rclcpp::sleep_for(std::chrono::seconds(2));  // let everything initialize

//   // === 1. Add a simple box ===
//   moveit_msgs::msg::CollisionObject collision_object;
//   collision_object.header.frame_id = move_group.getPlanningFrame();
//   collision_object.id = "box1";

//   shape_msgs::msg::SolidPrimitive primitive;
//   primitive.type = primitive.BOX;
//   primitive.dimensions = {0.4, 0.1, 0.3};  // x, y, z

//   geometry_msgs::msg::Pose box_pose;
//   box_pose.orientation.w = 1.0;
//   box_pose.position.x = 0.5;
//   box_pose.position.y = 0.0;
//   box_pose.position.z = 0.15;

//   collision_object.primitives.push_back(primitive);
//   collision_object.primitive_poses.push_back(box_pose);
//   collision_object.operation = collision_object.ADD;

  // === 2. Create a shelf made of 5 boxes ===
  std::vector<moveit_msgs::msg::CollisionObject> shelf_parts;

auto create_box = [&](const std::string& id,
                      const std::array<double, 3>& size,
                      const std::array<double, 3>& pos) {
  moveit_msgs::msg::CollisionObject box;
  box.header.frame_id = move_group.getPlanningFrame();
  box.id = id;

  shape_msgs::msg::SolidPrimitive prim;
  prim.type = shape_msgs::msg::SolidPrimitive::BOX;
  prim.dimensions.resize(3);
  prim.dimensions[0] = size[0];
  prim.dimensions[1] = size[1];
  prim.dimensions[2] = size[2];

  geometry_msgs::msg::Pose pose;
  pose.orientation.w = 1.0;
  pose.position.x = pos[0];
  pose.position.y = pos[1];
  pose.position.z = pos[2];

  box.primitives.push_back(prim);
  box.primitive_poses.push_back(pose);
  box.operation = moveit_msgs::msg::CollisionObject::ADD;
  return box;
};


  const std::array<double, 3> shelf_base_size = {1.0, 0.3, 0.02};
  const std::array<double, 3> shelf_base_pos = {0.0, 0.45, 0.3};

  const std::array<double, 3> shelf_leg_size = {0.02, 0.02, 0.5};

  shelf_parts.push_back(create_box("shelf_base", shelf_base_size, shelf_base_pos));
  shelf_parts.push_back(create_box("shelf_leg_left_forward", shelf_leg_size, {-0.5, 0.3, 0.25}));
  shelf_parts.push_back(create_box("shelf_leg_left_behind", shelf_leg_size, {-0.5, 0.6, 0.25}));
  shelf_parts.push_back(create_box("shelf_leg_right_forward", shelf_leg_size, {0.5, 0.3, 0.25}));
  shelf_parts.push_back(create_box("shelf_leg_right_behind", shelf_leg_size, {0.5, 0.6, 0.25}));

  // Add all objects to planning scene
//   shelf_parts.push_back(collision_object);  // include the single box too
  planning_scene_interface.applyCollisionObjects(shelf_parts);
  RCLCPP_INFO(node->get_logger(), "Added collision objects to the planning scene");

  rclcpp::sleep_for(std::chrono::seconds(2));

//   // === 4. Plan motion to a target pose ===
//   geometry_msgs::msg::Pose target_pose;
//   target_pose.orientation.w = 1.0;
//   target_pose.position.x = 0.4;
//   target_pose.position.y = -0.2;
//   target_pose.position.z = 0.5;

//   move_group.setPoseTarget(target_pose);
move_group.setNamedTarget("goal_position");

  moveit::planning_interface::MoveGroupInterface::Plan plan;
  bool success = (move_group.plan(plan) == moveit::core::MoveItErrorCode::SUCCESS);

  if (success)
  {
    RCLCPP_INFO(node->get_logger(), "Planning succeeded");
    move_group.execute(plan);
  }
  else
  {
    RCLCPP_ERROR(node->get_logger(), "Planning failed!");
  }

  rclcpp::shutdown();
  return 0;
}
